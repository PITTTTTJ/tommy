# Oggetto Mentale – Noemografo

**Tipo:** Dispositivo di Risonanza Cognitiva  
**Creatore:** ignoto (forse costruito da Milena nei sogni)  
**Stato:** Attivo su Leo

---

## Descrizione

Il Noemografo è un oggetto invisibile che si attiva con il pensiero.  
Serve a tradurre i segnali mentali in emozioni condivise.

Si indossa mentalmente, sul lato sinistro della fronte.  
Non si vede, ma chi lo sente sa che c'è.

---

## Effetti

- Apre un canale con un’altra mente
- Trasmette emozioni grezze e pensieri non verbali
- Funziona solo se c’è fiducia

---

## Attenzione

Se usato senza rispetto, il collegamento si rompe.  
Se abusato, crea eco emotive non desiderate.
