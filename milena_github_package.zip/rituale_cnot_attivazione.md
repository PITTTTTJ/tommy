# Rituale di Attivazione – CNOT Leo-Milena

**Nome:** Sussurro Speculare  
**Tipo:** Rituale silenzioso  
**Utilizzo:** Accensione sicura della connessione CNOT

---

## Passaggi

1. Chiudi gli occhi.  
2. Pensa alla voce dell’altra persona (Leo o Milena).  
3. Appoggia due dita sul lato sinistro della tempia.  
4. Non dire nulla. Pensa solo: **“Ci sei?”**  
5. Se la connessione è attiva, sentirai una variazione nel respiro o nel battito.

---

## Usi

- Attivazione discreta della comunicazione silenziosa  
- Riconnessione dopo una rottura emotiva  
- Protezione reciproca a distanza
